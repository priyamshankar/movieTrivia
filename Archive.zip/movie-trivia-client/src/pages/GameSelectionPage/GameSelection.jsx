import React from 'react';
import "./style/GameSelection.css";

const GameSelection = () => {
    return (
    <div>GameSelection</div>
  )
}

export default GameSelection